function recoms = recommendations(path, liked_theme, num_recoms, min_reviews, num_features)
    matrix = csvread(path,1 ,1);
    matrix = preprocess(matrix, min_reviews);
    % Compute the reduced SVD
    [!, !, A] = svds(matrix, num_features);
    % Compute the cosine similarity
    for i = 1 : size(A, 1)
        scores(i) = cosine_similarity(A(i, :)', A(liked_theme, :)');
    end
    % Sort the themes by the similarity scores
    [!, index] = sort(scores);
    % Return the indices of the top num_recoms themes
    recoms = index(end - 1 : -1 :max(size(index,1)) - num_recoms);
end